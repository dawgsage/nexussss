import { AlertTriangle } from 'lucide-react';

type Props = {
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel?: string;
  destructive?: boolean;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
};

export default function ConfirmDialog({
  title, message, confirmLabel, cancelLabel = 'Keep', destructive = false, busy = false, onConfirm, onCancel,
}: Props) {
  return (
    <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center px-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${destructive ? 'bg-red-50' : 'bg-amber-50'}`}>
          <AlertTriangle size={24} className={destructive ? 'text-red-500' : 'text-amber-500'} />
        </div>
        <h3 className="text-[#0F172A] font-bold text-lg text-center mb-2">{title}</h3>
        <p className="text-gray-500 text-sm text-center mb-5">{message}</p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            disabled={busy}
            className="flex-1 min-h-[44px] bg-gray-100 text-gray-700 font-bold py-3 rounded-full text-sm active:bg-gray-200 disabled:opacity-60"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            disabled={busy}
            className={`flex-1 min-h-[44px] text-white font-bold py-3 rounded-full text-sm active:scale-95 transition-all disabled:opacity-60 ${
              destructive ? 'bg-red-500 active:bg-red-600' : 'bg-gradient-to-r from-[#10B981] to-[#059669] shadow-lg shadow-[#10B981]/30'
            }`}
          >
            {busy ? 'Please wait...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
