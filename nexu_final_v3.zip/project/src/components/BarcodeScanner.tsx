import { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Camera, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

type Props = {
  expectedBarcode: string | null;
  onScan: (barcode: string) => void;
  onClose: () => void;
  onDemoScan?: () => void;
};

export default function BarcodeScanner({ expectedBarcode, onScan, onClose, onDemoScan }: Props) {
  const containerId = 'barcode-scanner-region';
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [status, setStatus] = useState<'starting' | 'scanning' | 'error'>('starting');
  const [errorMsg, setErrorMsg] = useState('');
  const scannedRef = useRef(false);
  const onScanRef = useRef(onScan);
  useEffect(() => { onScanRef.current = onScan; }, [onScan]);

  useEffect(() => {
    let mounted = true;
    const start = async () => {
      try {
        const scanner = new Html5Qrcode(containerId, { verbose: false });
        scannerRef.current = scanner;
        await scanner.start(
          { facingMode: 'environment' },
          { fps: 10, qrbox: { width: 250, height: 180 } },
          (_decodedText: string) => {
            if (scannedRef.current || !mounted) return;
            scannedRef.current = true;
            scanner.stop().then(() => onScanRef.current(_decodedText)).catch(() => onScanRef.current(_decodedText));
          },
          () => {}
        );
        if (mounted) setStatus('scanning');
      } catch (err) {
        if (mounted) {
          setStatus('error');
          setErrorMsg((err as Error).message || 'Camera access denied. Check browser permissions.');
        }
      }
    };
    start();

    return () => {
      mounted = false;
      const s = scannerRef.current;
      if (s) {
        s.stop().then(() => s.clear()).catch(() => {});
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black z-[60] flex flex-col">
      <div className="flex items-center justify-between px-4 pt-12 pb-4 bg-black/80">
        <div>
          <p className="text-white font-bold text-lg">Scan Barcode</p>
          {expectedBarcode && (
            <p className="text-blue-300 text-xs mt-0.5">Expected: {expectedBarcode}</p>
          )}
        </div>
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center active:bg-white/20"
        >
          <X size={20} className="text-white" />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center">
        {status === 'starting' && (
          <div className="flex flex-col items-center gap-3">
            <Loader2 size={32} className="text-[#10B981] animate-spin" />
            <p className="text-white/70 text-sm">Starting camera...</p>
          </div>
        )}

        {status === 'error' && (
          <div className="flex flex-col items-center gap-3 px-8 text-center">
            <AlertCircle size={36} className="text-red-400" />
            <p className="text-white font-medium">Camera unavailable</p>
            <p className="text-white/60 text-sm">{errorMsg}</p>
            <button onClick={onClose} className="mt-2 bg-white/10 text-white px-5 py-2.5 rounded-xl text-sm">Close</button>
          </div>
        )}

        <div id={containerId} className={`w-full h-full ${status === 'scanning' ? '' : 'absolute opacity-0 pointer-events-none'}`} />

        {status === 'scanning' && (
          <>
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-[250px] h-[180px] border-2 border-[#10B981] rounded-2xl shadow-lg" />
            </div>
            <div className="absolute bottom-20 left-0 right-0 text-center">
              <p className="text-white/80 text-sm flex items-center justify-center gap-1.5">
                <Camera size={14} /> Point at the barcode
              </p>
            </div>
          </>
        )}
      </div>

      <div className="pb-8 pt-3 px-4 bg-black/80">
        <button
          onClick={() => {
            if (scannedRef.current) return;
            scannedRef.current = true;
            if (onDemoScan) onDemoScan();
            else onScan(expectedBarcode ?? 'DEMO-0000000000');
          }}
          className="w-full bg-[#10B981]/15 border border-[#10B981]/40 text-[#10B981] text-sm font-semibold py-3 rounded-xl active:opacity-70"
        >
          Demo: Simulate Successful Scan
        </button>
      </div>
    </div>
  );
}

export function useBarcodeScanner() {
  const [open, setOpen] = useState(false);
  const openScanner = useCallback(() => setOpen(true), []);
  const closeScanner = useCallback(() => setOpen(false), []);
  return { open, openScanner, closeScanner };
}

export function ScanSuccess({ name, brand }: { name: string; brand: string }) {
  return (
    <div className="flex items-center gap-2 text-[#10B981]">
      <CheckCircle2 size={16} />
      <span className="text-sm font-medium">{name}{brand && ` — ${brand}`}</span>
    </div>
  );
}
