const KEY = 'nexu_my_orders';

export function getMyOrderIds(): string[] {
  try {
    const raw = localStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

export function rememberOrderId(id: string): void {
  try {
    const ids = getMyOrderIds().filter(x => x !== id);
    ids.unshift(id);
    localStorage.setItem(KEY, JSON.stringify(ids.slice(0, 50)));
  } catch { /* ignore */ }
}
