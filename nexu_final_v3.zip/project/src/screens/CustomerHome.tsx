import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import {
  MapPin, Search, X, ChevronRight, Loader2, AlertCircle, Store,
  Utensils, ShoppingCart, ShoppingBag, Package, Pill,
  Star, Clock, Bike, Wrench, Home as HomeIcon,
} from 'lucide-react';
import { fetchMerchants, type Merchant } from '@/lib/merchants';

type Props = {
  onOpenMerchant: (m: Merchant) => void;
  onBrowseAll: () => void;
};

const REGIONS = ['All Regions', 'NCR', 'Bulacan', 'Calabarzon', 'Dagupan', 'Region 3'];

type Service = {
  id: string;
  label: string;
  caption: string;
  icon: React.ReactNode;
  bg: string;
  iconBg: string;
  span: string;
};

// Bento box grid (4 columns) with vibrant pastel tiles
const SERVICES: Service[] = [
  { id: 'Food', label: 'Food', caption: 'Meals & drinks', icon: <Utensils size={30} />, bg: 'bg-orange-100', iconBg: 'bg-orange-300/70 text-orange-700', span: 'col-span-2 row-span-2' },
  { id: 'Grocery', label: 'Grocery', caption: 'Fresh picks', icon: <ShoppingCart size={22} />, bg: 'bg-emerald-100', iconBg: 'bg-emerald-300/70 text-emerald-800', span: 'col-span-2' },
  { id: 'Retail', label: 'Retail', caption: '', icon: <ShoppingBag size={20} />, bg: 'bg-sky-100', iconBg: 'bg-sky-300/70 text-sky-800', span: 'col-span-1' },
  { id: 'Pharmacy', label: 'Pharmacy', caption: '', icon: <Pill size={20} />, bg: 'bg-pink-100', iconBg: 'bg-pink-300/70 text-pink-700', span: 'col-span-1' },
  { id: 'Parcel', label: 'Parcel', caption: 'Send anything, anywhere', icon: <Package size={22} />, bg: 'bg-violet-100', iconBg: 'bg-violet-300/70 text-violet-700', span: 'col-span-4' },
];

const PROMO_BANNERS = [
  { id: 'b1', title: '20% OFF Your First Order', subtitle: 'Use code NEXU20 at checkout', bg: 'bg-gradient-to-r from-[#10B981] to-[#059669]' },
  { id: 'b2', title: 'Free Delivery Sundays', subtitle: 'On orders above ₱500', bg: 'bg-gradient-to-r from-[#0F172A] to-slate-700' },
  { id: 'b3', title: 'Earn While You Shop', subtitle: 'Become a NeXu Rider today', bg: 'bg-gradient-to-r from-amber-500 to-orange-500' },
];

function merchantDisplayCategory(m: Merchant): string {
  const retailNames = ['IKEA', 'Ace Hardware', 'Wilcon'];
  if (retailNames.some(n => m.name.includes(n))) return 'Retail';
  if (m.category === 'Restaurant') return 'Food';
  return m.category;
}

function categoryIcon(dispCat: string, size = 20) {
  if (dispCat === 'Food') return <Utensils size={size} />;
  if (dispCat === 'Retail') return <Wrench size={size} />;
  if (dispCat === 'Mall') return <HomeIcon size={size} />;
  return <ShoppingCart size={size} />;
}

function PromoCarousel() {
  const ref = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);

  const onScroll = () => {
    const el = ref.current;
    if (!el) return;
    const child = el.firstElementChild as HTMLElement | null;
    if (!child) return;
    const step = child.offsetWidth + 12;
    setIndex(Math.min(PROMO_BANNERS.length - 1, Math.max(0, Math.round(el.scrollLeft / step))));
  };

  // Auto-advance every 4s
  useEffect(() => {
    const t = setInterval(() => {
      const el = ref.current;
      if (!el) return;
      const child = el.firstElementChild as HTMLElement | null;
      if (!child) return;
      const step = child.offsetWidth + 12;
      const next = el.scrollLeft + step >= el.scrollWidth - el.clientWidth - 4 ? 0 : el.scrollLeft + step;
      el.scrollTo({ left: next, behavior: 'smooth' });
    }, 4000);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      <div ref={ref} onScroll={onScroll} className="flex gap-3 overflow-x-auto no-scrollbar snap-x-carousel px-4">
        {PROMO_BANNERS.map(b => (
          <div key={b.id} className={`${b.bg} rounded-2xl px-5 py-5 flex-shrink-0 w-[85%] max-w-[320px] flex flex-col gap-1 shadow-soft`}>
            <p className="text-white font-extrabold text-base leading-tight">{b.title}</p>
            <p className="text-white/80 text-xs">{b.subtitle}</p>
          </div>
        ))}
      </div>
      <div className="flex justify-center gap-1.5 mt-3">
        {PROMO_BANNERS.map((b, i) => (
          <span key={b.id} className={`h-1.5 rounded-full transition-all ${i === index ? 'w-5 bg-[#10B981]' : 'w-1.5 bg-gray-300'}`} />
        ))}
      </div>
    </div>
  );
}

function MerchantCard({ m, onOpen }: { m: Merchant; onOpen: (m: Merchant) => void }) {
  const dispCat = merchantDisplayCategory(m);
  return (
    <button
      onClick={() => onOpen(m)}
      className="w-full text-left bg-white rounded-2xl shadow-card active:scale-[0.98] transition-transform overflow-hidden"
    >
      {/* Large banner */}
      <div className="relative h-40 w-full overflow-hidden bg-emerald-50">
        {m.banner_url && <img src={m.banner_url} alt={m.name} loading="lazy" className="w-full h-full object-cover" />}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        <span className="absolute top-3 right-3 bg-[#F59E0B] text-[#0F172A] text-[11px] font-extrabold px-3 py-1 rounded-full shadow-md">
          20% OFF
        </span>
      </div>

      <div className="relative px-4 pb-4">
        {/* Overlapping logo */}
        <div className="w-14 h-14 rounded-2xl bg-white border-2 border-white shadow-soft flex items-center justify-center text-[#0F172A] -mt-7 relative z-10 overflow-hidden">
          {m.logo_url ? (
            <img src={m.logo_url} alt="" className="w-full h-full object-cover" />
          ) : (
            categoryIcon(dispCat, 22)
          )}
        </div>
        <p className="text-[#0F172A] font-bold text-base truncate mt-2">{m.name}</p>
        <div className="flex items-center flex-wrap gap-x-2 gap-y-1 mt-1.5 text-xs text-gray-500">
          <span className="flex items-center gap-1 font-semibold text-[#0F172A]">
            <Star size={12} className="fill-amber-400 text-amber-400" /> 4.8
          </span>
          <span className="text-gray-300">•</span>
          <span className="flex items-center gap-1"><Clock size={12} /> 25 mins</span>
          <span className="text-gray-300">•</span>
          <span className="flex items-center gap-1"><Bike size={12} /> ₱49 Delivery</span>
        </div>
        {(m.mall_name || m.region) && (
          <span className="text-[11px] font-medium text-gray-400 flex items-center gap-1 mt-1.5">
            <MapPin size={10} />
            {m.is_mall_tenant && m.mall_name ? `Inside ${m.mall_name}` : `${m.region ?? ''}${m.mall_name ? ` · ${m.mall_name}` : ''}`}
          </span>
        )}
      </div>
    </button>
  );
}

export default function CustomerHome({ onOpenMerchant, onBrowseAll }: Props) {
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [region, setRegion] = useState('All Regions');
  const [activeService, setActiveService] = useState<string | null>(null);
  const [regionOpen, setRegionOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setMerchants((await fetchMerchants()) ?? []);
      setError(null);
    } catch (e) {
      setError((e as Error)?.message ?? 'Please check your connection and try again.');
    }
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => {
    return merchants.filter(m => {
      if (!m.is_active) return false;
      if (region !== 'All Regions' && m.region !== region) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!m.name.toLowerCase().includes(q) && !(m.mall_name?.toLowerCase().includes(q) ?? false)) return false;
      }
      if (activeService) {
        const dispCat = merchantDisplayCategory(m);
        if (activeService === 'Food' && dispCat !== 'Food') return false;
        if (activeService === 'Grocery' && dispCat !== 'Grocery') return false;
        if (activeService === 'Retail' && dispCat !== 'Retail') return false;
        if (activeService === 'Pharmacy' && m.category !== 'Pharmacy') return false;
        if (activeService === 'Parcel') return false;
      }
      return true;
    });
  }, [merchants, region, search, activeService]);

  return (
    <div className="relative flex flex-col h-full bg-[#F8FAFC]">
      {/* Soft emerald gradient at the top */}
      <div className="absolute inset-x-0 top-0 h-80 bg-gradient-to-b from-emerald-200/80 via-emerald-50/70 to-transparent pointer-events-none" />

      {/* Header */}
      <div className="relative px-5 pt-12 pb-3 flex-shrink-0">
        <div className="flex items-center gap-1.5 mb-3">
          <MapPin size={14} className="text-[#059669]" />
          <p className="text-[#0F172A]/60 text-xs">Deliver to:</p>
          <p className="text-[#0F172A] text-sm font-bold">Current Location</p>
        </div>

        <div className="relative mb-3">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search stores, restaurants, pharmacies..."
            className="w-full bg-white shadow-soft rounded-full pl-10 pr-10 py-3 text-sm text-[#0F172A] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#10B981]/40"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 min-h-[44px] flex items-center">
              <X size={16} className="text-gray-500" />
            </button>
          )}
        </div>

        <div className="relative">
          <button
            onClick={() => setRegionOpen(v => !v)}
            className="inline-flex items-center gap-2 min-h-[40px] bg-white shadow-soft rounded-full px-4 text-sm text-[#0F172A] font-semibold active:scale-95 transition-transform"
          >
            <span>{region}</span>
            <ChevronRight size={14} className={`text-gray-500 transition-transform ${regionOpen ? 'rotate-90' : ''}`} />
          </button>
          {regionOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setRegionOpen(false)} />
              <div className="absolute top-full mt-2 left-0 w-56 bg-white rounded-2xl shadow-xl z-20 overflow-hidden">
                {REGIONS.map(r => (
                  <button key={r} onClick={() => { setRegion(r); setRegionOpen(false); }}
                    className={`w-full min-h-[44px] text-left px-4 py-3 text-sm font-medium hover:bg-gray-50 ${r === region ? 'text-[#10B981]' : 'text-gray-700'}`}>
                    {r}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Scrollable content */}
      <div className="relative flex-1 overflow-y-auto pb-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Loader2 size={28} className="text-[#10B981] animate-spin" />
            <p className="text-gray-500 text-sm">Loading stores near you...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-center px-6">
            <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center">
              <AlertCircle size={26} className="text-red-400" />
            </div>
            <p className="text-red-500 font-medium text-sm">Couldn't load stores</p>
            <p className="text-gray-500 text-xs">{error}</p>
            <button onClick={load} className="btn-primary text-sm px-6 py-3 min-h-[44px]">Retry</button>
          </div>
        ) : (
          <>
            {/* Promo carousel */}
            <div className="pt-2">
              <PromoCarousel />
            </div>

            {/* Bento box categories */}
            <div className="px-4 pt-5">
              <h2 className="text-[#0F172A] text-sm font-bold mb-3">What do you need?</h2>
              <div className="grid grid-cols-4 auto-rows-[76px] gap-3">
                {SERVICES.map(s => {
                  const active = activeService === s.id;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setActiveService(prev => prev === s.id ? null : s.id)}
                      className={`${s.span} ${s.bg} rounded-2xl p-3 flex flex-col justify-between text-left shadow-soft active:scale-95 transition-all ${
                        active ? 'ring-2 ring-[#10B981] ring-offset-2 ring-offset-[#F8FAFC]' : ''
                      }`}
                    >
                      <div className={`${s.iconBg} w-10 h-10 rounded-xl flex items-center justify-center`}>{s.icon}</div>
                      <div>
                        <p className="text-[#0F172A] font-extrabold text-sm leading-tight">{s.label}</p>
                        {s.caption && <p className="text-[#0F172A]/60 text-[11px] leading-tight mt-0.5">{s.caption}</p>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Stores */}
            <div className="px-4 pt-6">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-[#0F172A] text-sm font-bold">
                  {activeService ? `${activeService} Stores` : 'Stores Near You'}
                </h2>
                <button onClick={onBrowseAll} className="text-[#059669] text-xs font-bold flex items-center gap-0.5 min-h-[44px]">
                  See All <ChevronRight size={14} />
                </button>
              </div>
              {filtered.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-12 text-center">
                  <div className="w-16 h-16 bg-white shadow-soft rounded-full flex items-center justify-center">
                    <Store size={28} className="text-gray-400" />
                  </div>
                  <p className="text-gray-600 font-medium">{activeService === 'Parcel' ? 'Parcel pickup is coming soon' : 'No stores available in this area'}</p>
                  <p className="text-gray-500 text-sm">{activeService === 'Parcel' ? 'Pick another service to browse stores' : 'Try a different region or search term'}</p>
                  {(activeService || region !== 'All Regions' || search) && (
                    <button onClick={() => { setActiveService(null); setRegion('All Regions'); setSearch(''); }} className="btn-primary px-6 py-3 text-sm">Clear filters</button>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {filtered.map(m => <MerchantCard key={m.id} m={m} onOpen={onOpenMerchant} />)}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
