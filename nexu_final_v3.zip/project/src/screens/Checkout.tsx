import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, MapPin, CreditCard, Banknote, Smartphone, CheckCircle2, Loader2, AlertCircle, Store, X, Receipt } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useCart } from '@/lib/cart';
import { rememberOrderId } from '@/lib/myOrders';

const DELIVERY_FEE = 49;

type Props = {
  onBack: () => void;
  onSuccess: () => void;
};

type PaymentMethod = 'Cash' | 'GCash' | 'Card';

type NominatimResult = {
  place_id: number;
  display_name: string;
  lat: string;
  lon: string;
};

const SEARCH_DEBOUNCE_MS = 500;
const MIN_QUERY_LENGTH = 3;

const paymentOptions: { id: PaymentMethod; icon: React.ReactNode; cls: string }[] = [
  { id: 'Cash', icon: <Banknote size={16} />, cls: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  { id: 'GCash', icon: <Smartphone size={16} />, cls: 'bg-blue-50 text-blue-700 border-blue-200' },
  { id: 'Card', icon: <CreditCard size={16} />, cls: 'bg-slate-50 text-slate-700 border-slate-200' },
];

export default function Checkout({ onBack, onSuccess }: Props) {
  const { lines, merchantName, subtotal, clearCart } = useCart();
  const [address, setAddress] = useState('');
  const [payment, setPayment] = useState<PaymentMethod>('Cash');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<NominatimResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const skipNextSearch = useRef(false);

  // Debounced (500ms) OpenStreetMap Nominatim address search
  useEffect(() => {
    if (skipNextSearch.current) {
      skipNextSearch.current = false;
      return;
    }
    const query = address.trim();
    if (query.length < MIN_QUERY_LENGTH) {
      setSuggestions([]);
      setSearching(false);
      setSearchError(null);
      return;
    }

    const controller = new AbortController();
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=ph&limit=5`;
        const res = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error('Address search is unavailable right now.');
        const data = (await res.json()) as NominatimResult[];
        setSuggestions(data);
        setSearchError(null);
        setShowSuggestions(true);
        setSearching(false);
      } catch (e) {
        if ((e as Error).name === 'AbortError') return;
        setSuggestions([]);
        setSearchError('Could not search addresses. You can still type your address manually.');
        setShowSuggestions(true);
        setSearching(false);
      }
    }, SEARCH_DEBOUNCE_MS);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [address]);

  const handleAddressChange = (value: string) => {
    setAddress(value);
    setCoords(null);
  };

  const handleSelectSuggestion = (r: NominatimResult) => {
    skipNextSearch.current = true;
    setAddress(r.display_name);
    setCoords({ lat: parseFloat(r.lat), lng: parseFloat(r.lon) });
    setSuggestions([]);
    setShowSuggestions(false);
    setSearching(false);
    setSearchError(null);
  };

  const total = subtotal + DELIVERY_FEE;

  const handlePlaceOrder = async () => {
    if (!address.trim()) {
      setError('Please enter a delivery address.');
      return;
    }
    setPlacing(true);
    setError(null);
    try {
      const note = lines.map(l => `${l.quantity}x ${l.item.item_name}`).join(', ');
      const { data: inserted, error: insertError } = await supabase.from('orders').insert({
        pickup: merchantName ?? 'Unknown Merchant',
        dropoff: address.trim(),
        fare: total,
        distance: 5,
        vehicle_type: 'Motorcycle',
        note,
        status: 'Available',
        category: 'Food',
        toll_fee: 0,
        multi_store: false,
        payment_methods: [payment],
      }).select('id').single();
      if (insertError) throw insertError;
      if (inserted?.id) rememberOrderId(String(inserted.id));
      clearCart();
      onSuccess();
    } catch (e) {
      setError((e as Error)?.message ?? 'Could not place your order. Please try again.');
    }
    setPlacing(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC]">
      <div className="bg-white px-5 pt-12 pb-5 flex-shrink-0 border-b border-gray-100">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 mb-3 min-h-[44px] active:opacity-70">
          <ArrowLeft size={18} /><span className="text-sm font-medium">Back to Cart</span>
        </button>
        <h1 className="text-[#0F172A] text-2xl font-bold">Checkout</h1>
        <p className="text-gray-400 text-sm mt-0.5">Review and place your order</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {error && (
          <div className="bg-red-50 border border-red-100 rounded-xl px-4 py-3 flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle size={16} /> {error}
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Store size={15} className="text-[#10B981]" />
            <h3 className="text-[#0F172A] text-sm font-bold">Order From</h3>
          </div>
          <p className="text-gray-600 text-sm">{merchantName}</p>
          <div className="mt-3 space-y-1.5">
            {lines.map(line => (
              <div key={line.key} className="flex justify-between text-xs">
                <span className="text-gray-500">{line.quantity}x {line.item.item_name}</span>
                <span className="text-gray-700 font-medium">₱{(line.quantity * Number(line.item.price)).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <MapPin size={15} className="text-[#10B981]" />
            <h3 className="text-[#0F172A] text-sm font-bold">Delivery Address</h3>
          </div>
          <div className="relative">
            <textarea
              value={address}
              onChange={e => handleAddressChange(e.target.value)}
              onFocus={() => { if (suggestions.length > 0 || searchError) setShowSuggestions(true); }}
              placeholder="Search street, barangay, city (e.g. 123 Rizal St, Poblacion, Makati)"
              rows={3}
              className="w-full bg-gray-50 border border-gray-100 rounded-2xl pl-4 pr-10 py-3 text-sm text-[#0F172A] placeholder-gray-400 focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 resize-none"
            />
            <div className="absolute right-3 top-3">
              {searching ? (
                <Loader2 size={16} className="text-[#10B981] animate-spin" aria-label="Searching addresses" />
              ) : address ? (
                <button
                  type="button"
                  onClick={() => { handleAddressChange(''); setSuggestions([]); setShowSuggestions(false); }}
                  aria-label="Clear address"
                  className="min-w-[44px] min-h-[44px] -m-3 flex items-center justify-center"
                >
                  <X size={16} className="text-gray-400" />
                </button>
              ) : null}
            </div>
          </div>

          {showSuggestions && !searching && (suggestions.length > 0 || searchError || address.trim().length >= MIN_QUERY_LENGTH) && (
            <div className="mt-2 bg-white rounded-2xl shadow-card border border-gray-100 overflow-hidden">
              {searchError ? (
                <p className="px-4 py-3 text-xs text-amber-600">{searchError}</p>
              ) : suggestions.length === 0 ? (
                <p className="px-4 py-3 text-xs text-gray-500">No matches found. You can still use the address you typed.</p>
              ) : (
                suggestions.map(r => (
                  <button
                    key={r.place_id}
                    type="button"
                    onClick={() => handleSelectSuggestion(r)}
                    className="w-full min-h-[44px] flex items-start gap-2 text-left px-4 py-3 border-b last:border-b-0 border-gray-50 active:bg-emerald-50 hover:bg-emerald-50/60"
                  >
                    <MapPin size={14} className="text-[#10B981] mt-0.5 flex-shrink-0" />
                    <span className="text-xs text-[#0F172A] leading-snug">{r.display_name}</span>
                  </button>
                ))
              )}
            </div>
          )}

          {coords && (
            <p className="mt-2 text-[11px] text-emerald-700 flex items-center gap-1">
              <CheckCircle2 size={12} /> Location confirmed
            </p>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-card p-4">
          <h3 className="text-[#0F172A] text-sm font-bold mb-3">Payment Method</h3>
          <div className="space-y-2">
            {paymentOptions.map(opt => (
              <button
                key={opt.id}
                onClick={() => setPayment(opt.id)}
                className={`w-full min-h-[44px] flex items-center gap-3 rounded-xl border px-4 py-3 transition-colors ${
                  payment === opt.id ? `${opt.cls} border-current` : 'bg-gray-50 border-gray-200 text-gray-600'
                }`}
              >
                {opt.icon}
                <span className="text-sm font-semibold flex-1 text-left">{opt.id}</span>
                {payment === opt.id && <CheckCircle2 size={16} />}
              </button>
            ))}
          </div>
        </div>

        {/* Transparent pricing */}
        <div className="bg-white rounded-2xl shadow-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Receipt size={15} className="text-[#10B981]" />
            <h3 className="text-[#0F172A] text-sm font-bold">Order Summary</h3>
          </div>
          <div className="space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-gray-600 text-sm">Subtotal</span>
              <span className="text-[#0F172A] font-semibold text-sm">₱{subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 text-sm">Delivery Fee</span>
              <span className="text-[#0F172A] font-semibold text-sm">₱{DELIVERY_FEE}</span>
            </div>
            <div className="border-t border-dashed border-gray-200 pt-3 flex justify-between items-center">
              <span className="text-[#0F172A] font-extrabold text-base">Total</span>
              <span className="text-[#059669] font-black text-2xl">₱{total.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white border-t border-gray-100 px-4 py-4 flex-shrink-0">
        <button
          onClick={handlePlaceOrder}
          disabled={placing || lines.length === 0}
          className="btn-primary w-full text-lg py-4 min-h-[44px] tracking-wide"
        >
          {placing ? (
            <><Loader2 size={20} className="animate-spin" />Placing Order...</>
          ) : (
            <><CheckCircle2 size={20} />Place Order · ₱{total.toLocaleString()}</>
          )}
        </button>
        <p className="text-center text-gray-400 text-xs mt-2">By placing this order, a driver will be notified</p>
      </div>
    </div>
  );
}
