import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  ArrowLeft, Store, Loader2, AlertCircle, Package, Utensils, ShoppingCart,
  Pill, Coffee, TrendingUp, Tag, ChevronRight, Search, MapPin, X,
  ShoppingBag, Wrench, Home as HomeIcon, Plus, Check, AlertTriangle,
  Star, Clock, Bike,
} from 'lucide-react';
import { fetchMerchants, type Merchant } from '@/lib/merchants';
import { fetchMenuByMerchant, fetchGroceryComparisons, type MenuItem, type PriceComparison } from '@/lib/menu';
import { useCart } from '@/lib/cart';

type Props = {
  onBack: () => void;
  initialMerchant?: Merchant | null;
};

const REGIONS = ['All Regions', 'NCR', 'Bulacan', 'Calabarzon', 'Dagupan', 'Region 3'];

const SERVICE_ICONS = [
  { id: 'Food', label: 'Food', icon: <Utensils size={20} /> },
  { id: 'Grocery', label: 'Grocery', icon: <ShoppingCart size={20} /> },
  { id: 'Retail', label: 'Retail', icon: <ShoppingBag size={20} /> },
  { id: 'Parcel', label: 'Parcel', icon: <Package size={20} /> },
  { id: 'Pabili', label: 'Pabili', icon: <Store size={20} /> },
];

function merchantDisplayCategory(m: Merchant): string {
  const retailNames = ['IKEA', 'Ace Hardware', 'Wilcon'];
  if (retailNames.some(n => m.name.includes(n))) return 'Retail';
  if (m.category === 'Restaurant') return 'Food';
  return m.category;
}

export default function MerchantMenu({ onBack, initialMerchant = null }: Props) {
  const { addItem, merchantId: cartMerchantId, merchantName: cartMerchantName, lines } = useCart();
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [menuError, setMenuError] = useState<string | null>(null);
  const [compareError, setCompareError] = useState<string | null>(null);
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [itemsLoading, setItemsLoading] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [comparisons, setComparisons] = useState<PriceComparison[]>([]);
  const [search, setSearch] = useState('');
  const [region, setRegion] = useState('All Regions');
  const [activeService, setActiveService] = useState<string | null>(null);
  const [regionOpen, setRegionOpen] = useState(false);
  const [pendingItem, setPendingItem] = useState<{ item: MenuItem; merchant: Merchant } | null>(null);
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<string>('All');

  const load = useCallback(async () => {
    try {
      setMerchants((await fetchMerchants()) ?? []);
      setError(null);
    } catch (e) {
      setError((e as Error)?.message ?? 'Could not load merchants.');
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadComparisons = useCallback(async () => {
    setItemsLoading(true);
    setCompareError(null);
    try {
      setComparisons(await fetchGroceryComparisons());
    } catch (e) {
      setCompareError((e as Error)?.message ?? 'Could not load price comparisons.');
    }
    setItemsLoading(false);
  }, []);

  const openMerchant = useCallback(async (m: Merchant) => {
    setSelectedMerchant(m);
    setActiveTab('All');
    setItems([]);
    setMenuError(null);
    setItemsLoading(true);
    try {
      const data = await fetchMenuByMerchant(m.id);
      setItems(data ?? []);
    } catch (e) {
      setMenuError((e as Error)?.message ?? 'Could not load this menu.');
    }
    setItemsLoading(false);
  }, []);

  // Deep-link: open the merchant tapped on the home screen
  useEffect(() => {
    if (initialMerchant) void openMerchant(initialMerchant);
  }, [initialMerchant, openMerchant]);

  const filtered = useMemo(() => {
    return merchants.filter(m => {
      if (!m.is_active) return false;
      if (region !== 'All Regions' && m.region !== region) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!m.name.toLowerCase().includes(q) && !(m.mall_name?.toLowerCase().includes(q) ?? false)) return false;
      }
      if (activeService) {
        const dispCat = merchantDisplayCategory(m);
        if (activeService === 'Food' && dispCat !== 'Food') return false;
        if (activeService === 'Grocery' && dispCat !== 'Grocery') return false;
        if (activeService === 'Retail' && dispCat !== 'Retail') return false;
        if (activeService === 'Parcel' || activeService === 'Pabili') return false;
      }
      return true;
    });
  }, [merchants, region, search, activeService]);

  const categoryIcon = (cat: string) => {
    if (cat === 'Food') return <Utensils size={13} />;
    if (cat === 'Drink') return <Coffee size={13} />;
    if (cat === 'Grocery') return <ShoppingCart size={13} />;
    if (cat === 'Pharmacy') return <Pill size={13} />;
    if (cat === 'Retail') return <ShoppingBag size={13} />;
    if (cat === 'Snacks') return <Package size={13} />;
    if (cat === 'Cafe') return <Coffee size={13} />;
    return <Package size={13} />;
  };

  const formatPrice = (item: MenuItem) => {
    if (item.price_high && item.price_high > item.price) return `₱${item.price} – ₱${item.price_high}`;
    return `₱${item.price}`;
  };

  const handleAddItem = (item: MenuItem, merchant: Merchant) => {
    if (cartMerchantId && cartMerchantId !== merchant.id && lines.length > 0) {
      setPendingItem({ item, merchant });
      return;
    }
    doAddItem(item, merchant);
  };

  const doAddItem = (item: MenuItem, merchant: Merchant) => {
    addItem(item, merchant.id, merchant.name);
    setAddedIds(prev => { const s = new Set(prev); s.add(item.id); return s; });
    setTimeout(() => {
      setAddedIds(prev => { const s = new Set(prev); s.delete(item.id); return s; });
    }, 1500);
  };

  // ===== COMPARE PRICES VIEW =====
  if (compareMode) {
    return (
      <div className="flex flex-col h-full bg-[#F8FAFC]">
        <div className="bg-white px-5 pt-12 pb-4 flex-shrink-0 border-b border-gray-100">
          <button onClick={() => setCompareMode(false)} className="flex items-center gap-2 text-gray-500 mb-3 min-h-[44px] active:opacity-70">
            <ArrowLeft size={18} /><span className="text-sm font-medium">Back to Merchants</span>
          </button>
          <div className="flex items-center gap-2">
            <TrendingUp size={20} className="text-[#10B981]" />
            <h1 className="text-[#0F172A] text-xl font-bold">Compare Grocery Prices</h1>
          </div>
          <p className="text-gray-400 text-xs mt-1">See price differences across Puregold, SM & Robinsons</p>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {itemsLoading ? (
            <div className="flex items-center justify-center py-12"><Loader2 size={26} className="text-[#10B981] animate-spin" /></div>
          ) : compareError ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <AlertCircle size={28} className="text-red-400" />
              <p className="text-red-500 text-sm font-medium">{compareError}</p>
              <button onClick={loadComparisons} className="btn-primary px-6 py-3 text-sm">Retry</button>
            </div>
          ) : comparisons.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-16 text-center">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center"><TrendingUp size={28} className="text-gray-300" /></div>
              <p className="text-gray-500 font-medium">No price comparisons yet</p>
              <p className="text-gray-400 text-sm">Check back soon for grocery deals</p>
            </div>
          ) : (
            comparisons.filter(c => c.stores.length > 0).map(comp => {
              const minPrice = Math.min(...comp.stores.map(s => s.price));
              const maxPrice = Math.max(...comp.stores.map(s => s.price_high ?? s.price));
              return (
                <div key={comp.item_name} className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-[#0F172A] font-bold text-sm">{comp.item_name}</p>
                    <span className="text-[#10B981] text-xs font-bold whitespace-nowrap">₱{minPrice} – ₱{maxPrice}</span>
                  </div>
                  <p className="text-gray-400 text-xs mb-3">{comp.manufacturer}{comp.brand && ` · ${comp.brand}`}</p>
                  <div className="space-y-1.5">
                    {comp.stores.map(s => {
                      const isCheapest = s.price === minPrice;
                      return (
                        <div key={s.store_id} className={`flex items-center justify-between rounded-lg px-3 py-2 ${isCheapest ? 'bg-emerald-50 border border-emerald-200' : 'bg-gray-50'}`}>
                          <div className="flex items-center gap-1.5">
                            <Store size={12} className={isCheapest ? 'text-[#10B981]' : 'text-gray-400'} />
                            <span className="text-xs font-medium text-gray-700">{s.store_name}</span>
                            {isCheapest && <span className="text-[10px] font-bold text-[#10B981] bg-emerald-100 px-1.5 py-0.5 rounded-full">Best Price</span>}
                          </div>
                          <span className={`text-sm font-bold ${isCheapest ? 'text-[#10B981]' : 'text-gray-600'}`}>
                            {s.price_high ? `₱${s.price} – ₱${s.price_high}` : `₱${s.price}`}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  }

  // ===== SINGLE MERCHANT MENU VIEW =====
  if (selectedMerchant) {
    const grouped = items.reduce<Record<string, MenuItem[]>>((acc, item) => {
      (acc[item.category] ??= []).push(item);
      return acc;
    }, {});
    const catOrder = ['Food', 'Drink', 'Snacks', 'Grocery', 'Pharmacy', 'Retail'];
    const tabCats = ['All', ...catOrder.filter(c => grouped[c])];
    const filteredItems = activeTab === 'All' ? items : items.filter(i => i.category === activeTab);
    const filteredGrouped = filteredItems.reduce<Record<string, MenuItem[]>>((acc, item) => {
      (acc[item.category] ??= []).push(item);
      return acc;
    }, {});

    return (
      <div className="flex flex-col h-full bg-[#F8FAFC]">
        {/* Single scroll container so the tab bar can stick to the top */}
        <div className="flex-1 overflow-y-auto">
          <div className="bg-white px-5 pt-12 pb-4">
            <button onClick={() => { setSelectedMerchant(null); setActiveTab('All'); setMenuError(null); setPendingItem(null); }} className="flex items-center gap-2 text-gray-500 mb-3 min-h-[44px] active:opacity-70">
              <ArrowLeft size={18} /><span className="text-sm font-medium">Back to Merchants</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center overflow-hidden">
                {selectedMerchant.logo_url ? (
                  <img src={selectedMerchant.logo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <Store size={22} className="text-[#10B981]" />
                )}
              </div>
              <div>
                <h1 className="text-[#0F172A] text-xl font-bold">{selectedMerchant.name}</h1>
                {selectedMerchant.is_mall_tenant && selectedMerchant.mall_name ? (
                  <p className="text-gray-400 text-xs mt-0.5 flex items-center gap-1"><MapPin size={10} /> Inside {selectedMerchant.mall_name}</p>
                ) : selectedMerchant.region ? (
                  <p className="text-gray-400 text-xs mt-0.5 flex items-center gap-1"><MapPin size={10} /> {selectedMerchant.region}{selectedMerchant.mall_name ? ` · ${selectedMerchant.mall_name}` : ''}</p>
                ) : null}
              </div>
            </div>
          </div>

          {/* Sticky category tabs */}
          <div className="sticky top-0 z-20 bg-white/95 backdrop-blur px-4 py-3 border-b border-gray-100 shadow-soft">
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
              {tabCats.map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex items-center gap-1.5 px-4 py-3 min-h-[44px] rounded-full text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
                    activeTab === tab
                      ? 'bg-gradient-to-r from-[#10B981] to-[#059669] text-white shadow-glow'
                      : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  {tab === 'All' ? <Package size={12} /> : categoryIcon(tab)}
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="px-4 py-4 space-y-4">
            {itemsLoading ? (
              <div className="flex items-center justify-center py-12"><Loader2 size={26} className="text-[#10B981] animate-spin" /></div>
            ) : menuError ? (
              <div className="flex flex-col items-center gap-3 py-12 text-center">
                <AlertCircle size={28} className="text-red-400" />
                <p className="text-red-500 text-sm font-medium">Couldn't load this menu</p>
                <p className="text-gray-400 text-xs">{menuError}</p>
                <button onClick={() => void openMerchant(selectedMerchant)} className="btn-primary px-6 py-3 text-sm">Retry</button>
              </div>
            ) : filteredItems.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-16 text-center">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center"><Package size={28} className="text-gray-300" /></div>
                <p className="text-gray-500 font-medium">{items.length === 0 ? 'This menu is empty' : 'No items in this category'}</p>
                <p className="text-gray-400 text-sm">{items.length === 0 ? 'This store has no items yet. Check back soon!' : 'Try another category'}</p>
              </div>
            ) : (
              catOrder.filter(c => filteredGrouped[c]).map(cat => (
                <div key={cat}>
                  <div className="flex items-center gap-1.5 mb-2 px-1">
                    {categoryIcon(cat)}
                    <p className="text-gray-500 text-xs font-bold uppercase tracking-wide">{cat}</p>
                  </div>
                  <div className="space-y-3">
                    {filteredGrouped[cat].map(item => (
                      <div key={item.id} className="bg-white rounded-2xl shadow-card p-3">
                        <div className="flex gap-3 items-center">
                          {/* 80x80 image */}
                          <div className="flex-shrink-0">
                            {item.image_url ? (
                              <img src={item.image_url} alt={item.item_name} loading="lazy" className="w-20 h-20 rounded-xl object-cover" />
                            ) : (
                              <div className="w-20 h-20 rounded-xl bg-emerald-50 flex items-center justify-center">
                                <Utensils size={24} className="text-emerald-300" />
                              </div>
                            )}
                          </div>

                          {/* Name, description, price */}
                          <div className="flex-1 min-w-0 self-stretch flex flex-col justify-between py-0.5">
                            <div>
                              <p className="text-[#0F172A] font-bold text-[15px] leading-tight line-clamp-2">{item.item_name}</p>
                              {item.description && (
                                <p className="text-gray-500 text-xs mt-1 leading-snug line-clamp-2">{item.description}</p>
                              )}
                            </div>
                            <div className="flex items-center gap-1.5 mt-1">
                              <span className="text-[#0F172A] font-extrabold text-sm">{formatPrice(item)}</span>
                              {item.brand && (
                                <span className="text-[10px] font-medium text-gray-400 bg-gray-50 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                  <Tag size={9} />{item.brand}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* + Add pill */}
                          <div className="flex-shrink-0 self-end">
                            <button
                              onClick={() => handleAddItem(item, selectedMerchant)}
                              className="btn-primary px-4 py-3 text-xs"
                            >
                              {addedIds.has(item.id) ? <Check size={14} /> : <Plus size={14} />}
                              {addedIds.has(item.id) ? 'Added' : 'Add'}
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Cross-merchant confirm */}
        {pendingItem && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center px-6">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
              <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-4">
                <AlertTriangle size={24} className="text-amber-500" />
              </div>
              <h3 className="text-[#0F172A] font-bold text-lg text-center mb-2">Replace cart items?</h3>
              <p className="text-gray-500 text-sm text-center mb-5">
                Your cart has items from <span className="font-semibold text-[#0F172A]">{cartMerchantName}</span>.
                Adding from <span className="font-semibold text-[#0F172A]">{pendingItem.merchant.name}</span> will clear your current cart.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setPendingItem(null)}
                  className="flex-1 min-h-[44px] bg-gray-100 text-gray-700 font-bold tracking-wide py-3 rounded-full text-sm active:bg-gray-200 transition-all duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={() => { doAddItem(pendingItem.item, pendingItem.merchant); setPendingItem(null); }}
                  className="flex-1 min-h-[44px] bg-gradient-to-r from-[#10B981] to-[#059669] active:scale-95 text-white font-bold tracking-wide py-3 rounded-full text-sm shadow-lg shadow-[#10B981]/30 transition-all duration-200"
                >
                  Replace & Add
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ===== MERCHANT LIST / CUSTOMER HOME =====
  return (
    <div className="flex flex-col h-full bg-[#F8FAFC]">
      {/* Light header */}
      <div className="bg-white px-5 pt-12 pb-4 flex-shrink-0 border-b border-gray-100">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 mb-3 min-h-[44px] active:opacity-70">
          <ArrowLeft size={18} /><span className="text-sm font-medium">Back</span>
        </button>

        {/* Deliver to */}
        <div className="flex items-center gap-1.5 mb-3">
          <MapPin size={14} className="text-[#10B981]" />
          <p className="text-gray-400 text-xs">Deliver to:</p>
          <p className="text-[#0F172A] text-sm font-bold">Current Location</p>
        </div>

        {/* Search bar */}
        <div className="relative mb-3">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-300" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search malls, cafes, hardware..."
            className="w-full bg-gray-50 border border-gray-100 rounded-xl pl-9 pr-9 py-2.5 text-sm text-[#0F172A] placeholder-gray-400 focus:outline-none focus:border-[#10B981]"
          />
          {search && (
            <button onClick={() => setSearch('')} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 min-w-[44px] min-h-[44px] flex items-center justify-center">
              <X size={14} className="text-gray-400" />
            </button>
          )}
        </div>

        {/* Region filter */}
        <div className="relative mb-3">
          <button
            onClick={() => setRegionOpen(v => !v)}
            className="w-full min-h-[44px] flex items-center justify-between bg-gray-50 border border-gray-100 rounded-xl px-3 py-3 text-sm text-[#0F172A] font-medium"
          >
            <span>{region}</span>
            <ChevronRight size={14} className={`text-gray-400 transition-transform ${regionOpen ? 'rotate-90' : ''}`} />
          </button>
          {regionOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setRegionOpen(false)} />
              <div className="absolute top-full mt-1 left-0 right-0 bg-white border border-gray-100 rounded-xl shadow-xl z-20 overflow-hidden">
                {REGIONS.map(r => (
                  <button key={r} onClick={() => { setRegion(r); setRegionOpen(false); }}
                    className={`w-full min-h-[44px] text-left px-4 py-3 text-sm font-medium hover:bg-gray-50 ${r === region ? 'text-[#10B981]' : 'text-gray-700'}`}>
                    {r}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Service icons */}
        <div className="flex justify-between gap-2">
          {SERVICE_ICONS.map(s => (
            <button
              key={s.id}
              onClick={() => setActiveService(prev => prev === s.id ? null : s.id)}
              className="flex flex-col items-center gap-1.5 flex-1"
            >
              <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                activeService === s.id ? 'bg-[#10B981] text-white' : 'bg-gray-50 text-[#0F172A]'
              }`}>
                {s.icon}
              </div>
              <span className={`text-[10px] font-medium ${activeService === s.id ? 'text-[#10B981]' : 'text-gray-500'}`}>{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Compare prices button */}
      <div className="px-4 pt-3 pb-1 flex-shrink-0">
        <button
          onClick={() => { setCompareMode(true); loadComparisons(); }}
          className="w-full min-h-[44px] bg-[#10B981]/10 border border-[#10B981]/20 rounded-xl px-4 py-3 flex items-center justify-between active:opacity-70"
        >
          <div className="flex items-center gap-2">
            <TrendingUp size={16} className="text-[#10B981]" />
            <p className="text-[#0F172A] text-sm font-bold">Compare Grocery Prices</p>
          </div>
          <ChevronRight size={16} className="text-[#10B981]" />
        </button>
      </div>

      {/* Merchant cards */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center py-12"><Loader2 size={26} className="text-[#10B981] animate-spin" /></div>
        ) : error ? (
          <div className="flex flex-col items-center gap-2 py-8"><AlertCircle size={28} className="text-red-400" /><p className="text-red-500 text-sm font-medium">{error}</p><button onClick={load} className="btn-primary px-6 py-3 text-sm mt-1">Retry</button></div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-12 text-center"><div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center"><Store size={28} className="text-gray-300" /></div><p className="text-gray-500 font-medium">No merchants found</p><p className="text-gray-400 text-sm">Try a different region or search</p></div>
        ) : (
          filtered.map(m => {
            const dispCat = merchantDisplayCategory(m);
            const catIcon = dispCat === 'Food' ? <Utensils size={20} /> : dispCat === 'Retail' ? <Wrench size={20} /> : dispCat === 'Mall' ? <HomeIcon size={20} /> : <ShoppingCart size={20} />;
            return (
              <button
                key={m.id}
                onClick={() => openMerchant(m)}
                className="w-full text-left bg-white rounded-2xl shadow-[0_2px_12px_rgba(15,23,42,0.08)] active:scale-[0.98] transition-transform overflow-hidden"
              >
                {/* Banner image */}
                <div className="relative h-32 w-full overflow-hidden">
                  {m.banner_url ? (
                    <img src={m.banner_url} alt={m.name} loading="lazy" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-emerald-50" />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  {/* 20% OFF badge */}
                  <span className="absolute top-3 right-3 bg-[#F59E0B] text-[#0F172A] text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md">
                    20% OFF
                  </span>
                </div>

                {/* Overlapping logo */}
                <div className="relative px-4">
                  <div className="w-12 h-12 rounded-xl bg-white border-2 border-white shadow-md flex items-center justify-center flex-shrink-0 text-[#0F172A] -mt-6 relative z-10">
                    {catIcon}
                  </div>

                  {/* Store name + info row */}
                  <div className="mt-2 pb-3">
                    <p className="text-[#0F172A] font-bold text-sm truncate">{m.name}</p>
                    <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-gray-500">
                      <span className="flex items-center gap-0.5 font-semibold text-amber-500">
                        <Star size={12} className="fill-amber-500" /> 4.8
                      </span>
                      <span className="text-gray-300">·</span>
                      <span className="flex items-center gap-0.5">
                        <Clock size={12} className="text-gray-400" /> 25 mins
                      </span>
                      <span className="text-gray-300">·</span>
                      <span className="flex items-center gap-0.5">
                        <Bike size={12} className="text-gray-400" /> ₱49 Delivery
                      </span>
                    </div>
                    {m.is_mall_tenant && m.mall_name ? (
                      <span className="text-[10px] font-medium text-gray-400 flex items-center gap-0.5 mt-1.5">
                        <MapPin size={9} /> Inside {m.mall_name}
                      </span>
                    ) : m.mall_name ? (
                      <span className="text-[10px] font-medium text-gray-400 flex items-center gap-0.5 mt-1.5">
                        <MapPin size={9} /> {m.mall_name}
                      </span>
                    ) : m.region ? (
                      <span className="text-[10px] font-medium text-gray-400 flex items-center gap-0.5 mt-1.5">
                        <MapPin size={9} /> {m.region}
                      </span>
                    ) : null}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
