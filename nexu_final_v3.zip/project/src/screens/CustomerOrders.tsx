import { useEffect, useState, useCallback } from 'react';
import { ClipboardList, Loader2, AlertTriangle } from 'lucide-react';
import { supabase, type Order, formatPeso } from '@/lib/supabase';
import { getMyOrderIds } from '@/lib/myOrders';
import ConfirmDialog from '@/components/ConfirmDialog';

const CANCELLABLE = ['Pending', 'Available'];

const STATUS_STYLES: Record<string, string> = {
  Pending: 'bg-amber-50 text-amber-700 border-amber-200',
  Available: 'bg-amber-50 text-amber-700 border-amber-200',
  Accepted: 'bg-blue-50 text-blue-700 border-blue-200',
  Delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Cancelled: 'bg-red-50 text-red-700 border-red-200',
};

export default function CustomerOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toCancel, setToCancel] = useState<Order | null>(null);
  const [cancelling, setCancelling] = useState(false);

  const load = useCallback(async () => {
    const ids = getMyOrderIds();
    if (ids.length === 0) {
      setOrders([]); setError(null); setLoading(false);
      return;
    }
    try {
      const { data, error: err } = await supabase
        .from('orders').select('*').in('id', ids).order('created_at', { ascending: false });
      if (err) throw err;
      setOrders((data as Order[]) ?? []);
      setError(null);
    } catch (e) {
      setError((e as Error)?.message ?? 'Could not load your orders.');
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const channel = supabase
      .channel('orders-customer')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => { void load(); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [load]);

  const confirmCancel = async () => {
    if (!toCancel) return;
    setCancelling(true);
    try {
      const { error: err } = await supabase
        .from('orders').update({ status: 'Cancelled' }).eq('id', toCancel.id).in('status', CANCELLABLE);
      if (err) throw err;
      setToCancel(null);
      await load();
    } catch (e) {
      setError((e as Error)?.message ?? 'Could not cancel this order.');
      setToCancel(null);
    }
    setCancelling(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC]">
      <div className="bg-white px-5 pt-12 pb-5 flex-shrink-0 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <ClipboardList size={20} className="text-[#10B981]" />
          <h1 className="text-[#0F172A] text-2xl font-bold">My Orders</h1>
        </div>
        <p className="text-gray-400 text-sm mt-0.5">Track and manage your orders</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-40 gap-3">
            <Loader2 size={24} className="text-[#10B981] animate-spin" />
            <p className="text-gray-400 text-sm">Loading your orders...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3 text-center">
            <AlertTriangle size={26} className="text-red-400" />
            <p className="text-red-500 font-medium text-sm">Something went wrong</p>
            <p className="text-gray-400 text-xs">{error}</p>
            <button onClick={() => { setLoading(true); void load(); }} className="btn-primary px-6 py-3 text-sm">Retry</button>
          </div>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
              <ClipboardList size={28} className="text-gray-300" />
            </div>
            <p className="text-gray-500 font-medium">No orders yet</p>
            <p className="text-gray-400 text-sm">Orders you place will show up here</p>
          </div>
        ) : (
          orders.map(order => (
            <div key={order.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-[#0F172A] font-bold text-sm truncate">{order.pickup}</p>
                  <p className="text-gray-500 text-xs truncate mt-0.5">{order.note}</p>
                  <p className="text-gray-400 text-xs truncate mt-0.5">To: {order.dropoff}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-[#059669] text-lg font-black">{formatPeso(order.fare)}</p>
                  <span className={`inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${STATUS_STYLES[order.status] ?? 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                    {order.status}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between border-t border-gray-100 pt-2.5 mt-3">
                <p className="text-gray-400 text-xs">
                  {new Date(order.created_at).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}
                </p>
                {CANCELLABLE.includes(order.status) && (
                  <button
                    onClick={() => setToCancel(order)}
                    className="min-h-[44px] px-4 rounded-full border border-red-200 text-red-600 text-xs font-bold active:bg-red-50"
                  >
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {toCancel && (
        <ConfirmDialog
          title="Cancel Order"
          message="Are you sure you want to cancel this order?"
          confirmLabel="Cancel Order"
          cancelLabel="Keep Order"
          destructive
          busy={cancelling}
          onConfirm={confirmCancel}
          onCancel={() => setToCancel(null)}
        />
      )}
    </div>
  );
}

