import { useState, useEffect, useCallback } from 'react';
import {
  Wallet, TrendingUp, Package, Bike, Power, ChevronRight, Clock,
  MapPin, Timer,
} from 'lucide-react';
import { supabase, formatPeso } from '@/lib/supabase';
import NexuLogo from '@/components/NexuLogo';
import ConfirmDialog from '@/components/ConfirmDialog';

type Props = {
  isOnline: boolean;
  onToggleOnline: () => void;
  onGoToJobs: () => void;
};

export default function DriverDashboard({ isOnline, onToggleOnline, onGoToJobs }: Props) {
  const [todayEarnings, setTodayEarnings] = useState(0);
  const [completedJobs, setCompletedJobs] = useState(0);
  const [activeJobs, setActiveJobs] = useState(0);
  const [offers, setOffers] = useState<any[]>([]);
  const [confirmOffline, setConfirmOffline] = useState(false);

  const loadStats = useCallback(async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data: delivered } = await supabase
      .from('orders')
      .select('fare, status, created_at')
      .eq('status', 'Delivered')
      .gte('created_at', today.toISOString());

    const deliveredToday = delivered ?? [];
    setTodayEarnings(deliveredToday.reduce((sum, o) => sum + (o.fare ?? 0), 0));
    setCompletedJobs(deliveredToday.length);

    const { count } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'Accepted');

    setActiveJobs(count ?? 0);

    const { data: open } = await supabase
      .from('orders')
      .select('*')
      .not('status', 'in', '(Accepted,Delivered,Cancelled)')
      .order('created_at', { ascending: false })
      .limit(5);
    setOffers(open ?? []);
  }, []);

  const handleToggle = () => {
    if (isOnline) {
      setConfirmOffline(true);
    } else {
      onToggleOnline();
    }
  };

  useEffect(() => { loadStats(); }, [loadStats]);

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC]">
      <div className="bg-white px-5 pt-12 pb-5 flex-shrink-0 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <NexuLogo size={32} />
            <div>
              <p className="text-gray-400 text-[10px] font-medium tracking-widest uppercase">Welcome back</p>
              <h1 className="text-[#0F172A] text-xl font-bold tracking-tight">Driver Dashboard</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* Earnings card */}
        <div className="rounded-3xl p-6 bg-gradient-to-br from-emerald-50 via-white to-teal-50 border border-emerald-100 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <Wallet size={16} className="text-[#059669]" />
            <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider">Today's Earnings</p>
          </div>
          <p className="text-[#0F172A] text-4xl font-black tracking-tight">{formatPeso(todayEarnings)}</p>
          <p className="text-gray-400 text-xs mt-1">{completedJobs} completed {completedJobs === 1 ? 'delivery' : 'deliveries'} today</p>
        </div>

        {/* Online/Offline toggle */}
        <button
          onClick={handleToggle}
          className={`w-full rounded-full py-5 px-6 flex items-center justify-center gap-3 font-bold text-lg tracking-wide transition-all duration-200 active:scale-95 ${
            isOnline
              ? 'bg-gradient-to-r from-[#10B981] to-[#059669] text-white shadow-lg shadow-[#10B981]/40'
              : 'bg-gray-200 text-gray-500'
          }`}
        >
          <Power size={24} />
          {isOnline ? 'Go Offline' : 'Go Online'}
        </button>

        {/* Daily overview card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-[#10B981]" />
            <h2 className="text-[#0F172A] text-sm font-bold uppercase tracking-wide">Daily Overview</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="text-center">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center mx-auto mb-2">
                <Package size={18} className="text-blue-500" />
              </div>
              <p className="text-[#0F172A] text-lg font-black">{completedJobs}</p>
              <p className="text-gray-400 text-[10px] font-medium mt-0.5">Completed</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center mx-auto mb-2">
                <Bike size={18} className="text-amber-500" />
              </div>
              <p className="text-[#0F172A] text-lg font-black">{activeJobs}</p>
              <p className="text-gray-400 text-[10px] font-medium mt-0.5">Active Job</p>
            </div>
          </div>
        </div>

        {/* Jobs feed or offline message */}
        {isOnline ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-[#0F172A] text-sm font-bold uppercase tracking-wide">Available Orders</h2>
              <button onClick={onGoToJobs} className="min-h-[44px] text-[#059669] text-xs font-semibold flex items-center">
                View all <ChevronRight size={14} />
              </button>
            </div>
            {offers.length === 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-center">
                <p className="text-gray-500 font-semibold text-sm">No offers right now</p>
                <p className="text-gray-400 text-xs mt-1">New orders will appear here</p>
              </div>
            )}
            {offers.slice(0, 3).map((o) => {
              const dist = Number(o.distance) || 0;
              const half = (dist / 2).toFixed(1);
              const mins = Math.round(dist * 3);
              return (
                <button
                  key={o.id}
                  onClick={onGoToJobs}
                  className="w-full bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-left active:scale-[0.98] transition-transform"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-[#0F172A] font-semibold text-sm truncate">
                        {o.pickup}
                      </p>
                      <p className="text-gray-400 text-xs truncate mt-0.5">→ {o.dropoff}</p>
                      <div className="flex items-center gap-1.5 mt-2 text-gray-500 text-xs">
                        <MapPin size={12} className="text-[#10B981] flex-shrink-0" />
                        <span>{half} km to Store • {half} km to Customer</span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5 text-gray-500 text-xs">
                        <Timer size={12} className="text-amber-500 flex-shrink-0" />
                        <span>⏱️ {mins} mins • {dist} km total</span>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-[#059669] text-2xl font-black leading-none">{formatPeso(o.fare ?? 0)}</p>
                      <p className="text-gray-400 text-[10px] font-medium mt-1 uppercase tracking-wide">Fare</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 text-center">
            <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3">
              <Clock size={26} className="text-gray-300" />
            </div>
            <p className="text-gray-500 font-semibold text-sm">You are offline</p>
            <p className="text-gray-400 text-xs mt-1">Go online to see offers</p>
          </div>
        )}
      </div>

      {confirmOffline && (
        <ConfirmDialog
          title="Go offline?"
          message="Are you sure? You won't receive orders while offline."
          confirmLabel="Go Offline"
          cancelLabel="Stay Online"
          onConfirm={() => { setConfirmOffline(false); onToggleOnline(); }}
          onCancel={() => setConfirmOffline(false)}
        />
      )}
    </div>
  );
}
